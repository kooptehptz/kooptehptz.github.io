<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', '');

/** Имя пользователя MySQL */
define('DB_USER', '');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', '');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

define('WP_MEMORY_LIMIT', '512M');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'A5MbQaow|MOullR1P ,z|!=5H3ut1%6wpcmfYT|pq2{#|3|VcRYJ8ra.VHC!RwXx');
define('SECURE_AUTH_KEY',  '/y9c9ba>7Mqr:/R51ce#z+SVl_H)1e&0`?5 >7}w837ceD1c}K+65I{t}gF@-@3.');
define('LOGGED_IN_KEY',    'RQJ:cp.}lmMH>PwPvBd(jmc3N9RQM+pCX%(v0J%&1=L:}n~o15!q,}X+Gu)$/9o&');
define('NONCE_KEY',        'pXt+U~,YC{^ts5$:Q7ny!f4gB[Y6;FH7NQs[cwb6b?g VMp-0j[!n0tmQkLH({^X');
define('AUTH_SALT',        'CUU<*fN3T62x.e0re$6kf~@J )L$YCFv7v=YmyS?pw<Ji#T%fyZN#DUG_Vk(1;u*');
define('SECURE_AUTH_SALT', 'R+jz*yT_hpp5UN1nui4mo%[.2@$WZZkG5JDToylgEfiR/.y?^.yF^%5F,79$(<n,');
define('LOGGED_IN_SALT',   '$I*Wu=:@hWXvA<I~}|>`V,)$u`QIlT/#ldryOqGLO?^ywh+8[Sa{0{;?01j9lJod');
define('NONCE_SALT',       '?+PT~O<l0lV~,HLz4y%y?}%(VYW~gG>EtI|o9CRSC_ Jlrs{zzu>uCXHv,Sla0W,');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'geff_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
